SELECT
  r.Vehical_id,
  o.Product_Name,
  SUM(o.Quantity) AS Total_Quantity
FROM
  Orders o
  INNER JOIN Customer c ON o.Customer_id = c.Customer_id
  INNER JOIN Routes r ON c.Route_id = r.Route_id
  INNER JOIN Vehicles v ON r.Vehical_id = v.Vehicle_id
WHERE
  o.Order_status = 'Confirmed'
  AND o.Delivery_date BETWEEN "2024-01-09"
  AND "2024-03-21" 
GROUP BY
  r.Vehical_id;